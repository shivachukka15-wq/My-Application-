const seatsContainer = document.getElementById("seats");
const selectedSeatsText = document.getElementById("selectedSeats");
const totalText = document.getElementById("total");
const successBox = document.getElementById("success");

const seatPrice = 180;
const selectedSeats = [];

for (let i = 1; i <= 30; i++) {
  const seat = document.createElement("button");
  seat.className = "seat";
  seat.textContent = i;
  seat.type = "button";

  seat.addEventListener("click", () => {
    const index = selectedSeats.indexOf(i);

    if (index === -1) {
      selectedSeats.push(i);
      seat.classList.add("selected");
    } else {
      selectedSeats.splice(index, 1);
      seat.classList.remove("selected");
    }

    updateBooking();
  });

  seatsContainer.appendChild(seat);
}

function updateBooking() {
  selectedSeats.sort((a, b) => a - b);

  selectedSeatsText.textContent =
    selectedSeats.length ? selectedSeats.join(", ") : "None";

  totalText.textContent = "₹" + (selectedSeats.length * seatPrice);
}

function bookTicket() {
  const movie = document.getElementById("movie").value;

  if (selectedSeats.length === 0) {
    alert("Please select at least one seat.");
    return;
  }

  successBox.classList.remove("hidden");
  successBox.innerHTML =
    "✅ <strong>Booking Successful!</strong><br>" +
    "Movie: " + movie + "<br>" +
    "Seats: " + selectedSeats.join(", ") + "<br>" +
    "Total: ₹" + (selectedSeats.length * seatPrice);

  // Give the user time to see the success message,
  // then close the booking window.
  setTimeout(() => {
    window.close();
  }, 1800);
}
