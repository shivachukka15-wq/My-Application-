function openBooking() {
  window.open(
    "booking.html",
    "bookingWindow",
    "width=600,height=700,resizable=yes,scrollbars=yes"
  );
}
